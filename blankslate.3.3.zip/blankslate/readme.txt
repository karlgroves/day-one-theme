IMPORTANT - PLEASE READ: tidythemes.com/concept

YOU MAY DELETE THIS FILE AND ANY OTHER FILE(S) BEFORE STARTING YOUR PROJECT

- - THEME - -

BlankSlate WordPress Theme | Demo: wp-themes.com/blankslate

- - DESCRIPTION - -

This theme is aimed at web professionals, but is of course available and supported for anyone.

The bare essentials of a WordPress theme, no visual CSS styles added except for the CSS reset and the mandatory WP classes. 
Perfect for those who would like to build their own theme completely from scratch.

One custom menu and one widgetized sidebar to get you started.

If you'd like a jumpstart with CSS and more custom menus, page templates and widgetized areas, checkout SuperSimple:
tidythemes.com/supersimple

- - LICENSE - -

Technical Stuff: GNU General Public License | https://www.gnu.org/licenses/gpl.html

Friendly Stuff:
BlankSlate is 100% free and open source: 
perfect to build your own themes or use as a base for client projects.

- - SUPPORT - -

tidythemes.com/forum

Enjoy. Thanks, TidyThemes | tidythemes.com